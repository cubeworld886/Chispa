function defaultAudioFactory(doc) {
  if (doc?.createElement) return doc.createElement('audio');
  if (typeof globalThis.Audio === 'function') return new globalThis.Audio();
  return null;
}

function uniqueElements(elements) {
  return [...new Set(Array.from(elements || []).filter(Boolean))];
}

export class PageMusicDirector {
  constructor({
    url,
    doc = globalThis.document,
    legacyElements = [],
    audioFactory = () => defaultAudioFactory(doc),
  } = {}) {
    if (!url) throw new Error('PageMusicDirector requires the Dandara track URL');
    this.url = url;
    this.doc = doc;
    this.legacyElements = uniqueElements(legacyElements);
    this.audioFactory = audioFactory;
    this.track = null;
    this.preloaded = false;
    this.cueRequested = false;
    this.started = false;
    this.waitingActivation = false;
    this.destroyed = false;
    this.guardInstalled = false;
    this.activationHandler = null;
    this.playGuard = (event) => {
      const target = event?.target;
      if (!target || target === this.track) return;
      try { target.pause?.(); } catch {}
    };
  }

  #allLegacyAudio() {
    const discovered = this.doc?.querySelectorAll?.('audio') ?? [];
    return uniqueElements([...this.legacyElements, ...Array.from(discovered)]).filter((element) => element !== this.track);
  }

  silenceLegacy() {
    for (const element of this.#allLegacyAudio()) {
      try { element.pause?.(); } catch {}
    }
    if (!this.guardInstalled) {
      this.doc?.addEventListener?.('play', this.playGuard, true);
      this.guardInstalled = true;
    }
  }

  async preload() {
    if (this.destroyed) return false;
    this.silenceLegacy();
    if (!this.track) this.track = this.audioFactory?.() ?? null;
    if (!this.track) return false;

    this.track.src = this.url;
    this.track.preload = 'auto';
    this.track.loop = false;
    this.track.playsInline = true;
    this.track.autoplay = false;
    if (this.track.dataset) this.track.dataset.cosmicMusic = 'dandara';
    try { this.track.load?.(); } catch {}
    this.preloaded = true;
    return true;
  }

  async #attemptPlayFromZero() {
    if (!this.track || this.destroyed) return false;
    this.silenceLegacy();
    this.track.loop = false;
    try { this.track.currentTime = 0; } catch {}
    try {
      const result = this.track.play?.();
      if (result && typeof result.then === 'function') await result;
      this.started = true;
      this.waitingActivation = false;
      return true;
    } catch {
      this.started = false;
      return false;
    }
  }

  #removeActivationRecovery() {
    if (!this.activationHandler) return;
    for (const type of ['pointerdown', 'touchend', 'keydown']) {
      this.doc?.removeEventListener?.(type, this.activationHandler, true);
    }
    this.activationHandler = null;
    this.waitingActivation = false;
  }

  #installActivationRecovery() {
    if (this.activationHandler || this.destroyed) return;
    this.waitingActivation = true;
    this.activationHandler = async () => {
      const handler = this.activationHandler;
      if (!handler) return;
      this.#removeActivationRecovery();
      const ok = await this.#attemptPlayFromZero();
      if (!ok) this.#installActivationRecovery();
    };
    for (const type of ['pointerdown', 'touchend', 'keydown']) {
      this.doc?.addEventListener?.(type, this.activationHandler, true);
    }
  }

  async startFromBeginning() {
    if (this.destroyed) return false;
    if (!this.preloaded) await this.preload();
    if (this.started) return true;
    if (this.cueRequested && this.waitingActivation) return false;
    this.cueRequested = true;
    const ok = await this.#attemptPlayFromZero();
    if (!ok) this.#installActivationRecovery();
    return ok;
  }

  keepPlayingThroughIdle() {
    return this.started || this.waitingActivation;
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.#removeActivationRecovery();
    if (this.guardInstalled) {
      this.doc?.removeEventListener?.('play', this.playGuard, true);
      this.guardInstalled = false;
    }
    try { this.track?.pause?.(); } catch {}
  }
}
