export const AUTOSTART_DELAY_MS = 3000;
export const MUSIC_CUE_SECONDS = 7.55;
export const LAVENDER_REVEAL_SECONDS = 10.45;
export const IDLE_SECONDS = 14.00;

export const COSMIC_PHASES = Object.freeze({
  hold: Object.freeze({ name: 'hold', start: 0.00, end: 1.20 }),
  tension: Object.freeze({ name: 'tension', start: 1.20, end: 2.65 }),
  crackSeed: Object.freeze({ name: 'crackSeed', start: 2.65, end: 3.35 }),
  crackPropagation: Object.freeze({ name: 'crackPropagation', start: 3.35, end: 4.15 }),
  shardWaveA: Object.freeze({ name: 'shardWaveA', start: 4.15, end: 4.75 }),
  shardWaveB: Object.freeze({ name: 'shardWaveB', start: 4.75, end: 5.35 }),
  shardWaveC: Object.freeze({ name: 'shardWaveC', start: 5.35, end: 5.95 }),
  singularity: Object.freeze({ name: 'singularity', start: 5.95, end: 6.45 }),
  primaryFlash: Object.freeze({ name: 'primaryFlash', start: 6.45, end: 6.70 }),
  bigBang: Object.freeze({ name: 'bigBang', start: 6.52, end: 7.55 }),
  debrisExpansion: Object.freeze({ name: 'debrisExpansion', start: 7.10, end: 9.25 }),
  aftermath: Object.freeze({ name: 'aftermath', start: 9.25, end: 10.20 }),
  lavenderFlash: Object.freeze({ name: 'lavenderFlash', start: 10.20, end: 10.55 }),
  lavenderReveal: Object.freeze({ name: 'lavenderReveal', start: 10.45, end: 11.35 }),
  realization: Object.freeze({ name: 'realization', start: 11.35, end: IDLE_SECONDS }),
  melancholicIdle: Object.freeze({ name: 'melancholicIdle', start: IDLE_SECONDS, end: Infinity }),
});

export const durationUntilIdle = IDLE_SECONDS;

const NARRATIVE_PRECEDENCE = Object.freeze([
  COSMIC_PHASES.lavenderFlash,
  COSMIC_PHASES.primaryFlash,
  COSMIC_PHASES.debrisExpansion,
  COSMIC_PHASES.bigBang,
  COSMIC_PHASES.lavenderReveal,
  COSMIC_PHASES.melancholicIdle,
  COSMIC_PHASES.realization,
  COSMIC_PHASES.aftermath,
  COSMIC_PHASES.singularity,
  COSMIC_PHASES.shardWaveC,
  COSMIC_PHASES.shardWaveB,
  COSMIC_PHASES.shardWaveA,
  COSMIC_PHASES.crackPropagation,
  COSMIC_PHASES.crackSeed,
  COSMIC_PHASES.tension,
  COSMIC_PHASES.hold,
]);

function safeSeconds(inputSeconds) {
  return Number.isFinite(inputSeconds) && inputSeconds >= 0 ? inputSeconds : 0;
}

export function phaseProgress(phase, seconds) {
  if (!phase || !Number.isFinite(seconds) || phase.end === Infinity) return 0;
  const duration = phase.end - phase.start;
  if (duration <= 0) return 1;
  return Math.min(1, Math.max(0, (seconds - phase.start) / duration));
}

export function progressFor(name, inputSeconds) {
  const phase = COSMIC_PHASES[name];
  if (!phase) return 0;
  const seconds = safeSeconds(inputSeconds);
  if (seconds < phase.start || seconds >= phase.end) return 0;
  if (phase.end === Infinity) return 1;
  return phaseProgress(phase, seconds);
}

export function completedProgressFor(name, inputSeconds) {
  const phase = COSMIC_PHASES[name];
  if (!phase) return 0;
  const seconds = safeSeconds(inputSeconds);
  if (seconds < phase.start) return 0;
  if (phase.end === Infinity || seconds >= phase.end) return 1;
  return phaseProgress(phase, seconds);
}

export function samplePhaseWindows(inputSeconds) {
  const windows = {};
  for (const name of Object.keys(COSMIC_PHASES)) windows[name] = progressFor(name, inputSeconds);
  return Object.freeze(windows);
}

export function phaseAt(inputSeconds) {
  const seconds = safeSeconds(inputSeconds);
  const phase = NARRATIVE_PRECEDENCE.find((candidate) => (
    seconds >= candidate.start && seconds < candidate.end
  )) ?? COSMIC_PHASES.melancholicIdle;

  return Object.freeze({
    ...phase,
    progress: phase.end === Infinity ? 1 : phaseProgress(phase, seconds),
    seconds,
  });
}
