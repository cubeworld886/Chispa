function browserScheduler() {
  return {
    setTimeout: (fn, ms) => globalThis.setTimeout(fn, ms),
    clearTimeout: (id) => globalThis.clearTimeout(id),
    requestAnimationFrame: (fn) => globalThis.requestAnimationFrame(fn),
    cancelAnimationFrame: (id) => globalThis.cancelAnimationFrame(id),
    now: () => globalThis.performance?.now?.() ?? Date.now(),
  };
}

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const lerp = (a, b, t) => a + (b - a) * t;

export class MelancholicIdleDirector {
  constructor({ actor, scheduler = browserScheduler(), random = Math.random, targetProvider = () => [] }) {
    this.actor = actor;
    this.scheduler = scheduler;
    this.random = random;
    this.targetProvider = targetProvider;
    this.running = false;
    this.timeoutIds = new Set();
    this.rafId = null;
    this.startedAt = 0;
    this.targetIndex = 0;
    this.travel = { x: 0, y: 0 };
    this.travelTarget = { x: 0, y: 0 };
    this.hasInspectionTarget = false;
    this.lastFrameAt = 0;
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.startedAt = this.scheduler.now();
    this.lastFrameAt = this.startedAt;
    this.actor.setEyeOpenness?.(0.56, 0.56);
    this.#observeNextTarget();
    this.#schedule(() => this.#scheduleBlink(), this.#between(2000, 4000));
    this.rafId = this.scheduler.requestAnimationFrame((time) => this.#drift(time));
  }

  stop() {
    if (!this.running) return;
    this.running = false;
    for (const id of this.timeoutIds) this.scheduler.clearTimeout(id);
    this.timeoutIds.clear();
    if (this.rafId != null) this.scheduler.cancelAnimationFrame(this.rafId);
    this.rafId = null;
    this.actor.setEyeOpenness?.(0.56, 0.56);
    this.actor.applyIdleDrift?.(0, 0);
  }

  #between(min, max) {
    return Math.round(lerp(min, max, clamp(this.random(), 0, 1)));
  }

  #schedule(fn, ms) {
    const id = this.scheduler.setTimeout(() => {
      this.timeoutIds.delete(id);
      if (this.running) fn();
    }, ms);
    this.timeoutIds.add(id);
    return id;
  }

  #observeNextTarget() {
    const targets = this.targetProvider?.() ?? [];
    if (targets.length) {
      const target = targets[this.targetIndex % targets.length];
      this.targetIndex += 1;
      this.actor.setEyeOpenness?.(0.56, 0.56);
      this.actor.lookAtWorldPoint?.(target.x, target.y);
      const offset = this.actor.inspectionOffsetForWorldPoint?.(target.x, target.y);
      if (offset && Number.isFinite(offset.x) && Number.isFinite(offset.y)) {
        this.travelTarget = { x: offset.x, y: offset.y };
        this.hasInspectionTarget = true;
      }
    } else {
      this.hasInspectionTarget = false;
      this.actor.setEyeOpenness?.(0.56, 0.56);
      this.actor.lookDown?.();
      this.actor.lookAtWorldPoint?.(0.5, 0.67, { normalized: true });
    }
  }

  #scheduleBlink() {
    this.#schedule(() => this.#blink(), this.#between(1000, 3000));
  }

  #blink() {
    this.actor.setEyeOpenness?.(0.1, 0.1);
    this.#schedule(() => {
      this.actor.setEyeOpenness?.(0.56, 0.56);
      this.actor.lookDown?.();
      this.#schedule(() => {
        this.#observeNextTarget();
        this.#scheduleBlink();
      }, this.#between(3000, 6000));
    }, this.#between(180, 360));
  }

  #drift(time) {
    if (!this.running) return;
    const now = Number.isFinite(time) ? time : this.scheduler.now();
    const elapsed = Math.max(0, (now - this.startedAt) / 1000);
    const dt = Math.max(0, Math.min(0.25, (now - this.lastFrameAt) / 1000));
    this.lastFrameAt = now;

    let moveX;
    let moveY;
    if (this.hasInspectionTarget) {
      const alpha = 1 - Math.exp(-dt / 4.5);
      this.travel.x += (this.travelTarget.x - this.travel.x) * alpha;
      this.travel.y += (this.travelTarget.y - this.travel.y) * alpha;
      moveX = this.travel.x + Math.sin(elapsed * 0.28) * 0.0015;
      moveY = this.travel.y + Math.sin(elapsed * 0.23 + 0.8) * 0.001;
    } else {
      moveX = Math.sin(elapsed * 0.075) * 0.085 + Math.sin(elapsed * 0.031 + 1.4) * 0.04;
      moveY = Math.sin(elapsed * 0.058 + 0.7) * 0.055 + Math.sin(elapsed * 0.024 + 2.1) * 0.018 + 0.018;
    }
    this.actor.applyIdleDrift?.(moveX, moveY);
    this.rafId = this.scheduler.requestAnimationFrame((nextTime) => this.#drift(nextTime));
  }
}
