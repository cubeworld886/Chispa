import { ConstellationFracture } from './constellation-fracture.js';
import { CosmicAudioDirector } from './cosmic-audio.js';
import { CosmicEventController, createDomCosmicSceneView } from './cosmic-event.js';
import { CosmicRenderer } from './cosmic-renderer.js';
import { ChispaLavenderHost } from './lavender-host.js';
import { PageMusicDirector } from './page-music.js';
import { detectBrowserQualityEnvironment, selectQualityProfile } from './quality-profile.js';
import { productionWebglAdapter } from './webgl-adapter.js';

export async function loadCanonicalLavenderEngine(siteRoot) {
  const assets = await import('../lavender-runtime/dist/runtimeAssetBase.js');
  assets.setLavenderAssetBase(siteRoot);
  const runtime = await import('../lavender-runtime/dist/renderer/LavenderSvgEngine.js');
  return runtime.LavenderSvgEngine;
}

const DEFAULT_DEPENDENCIES = Object.freeze({
  ConstellationFracture,
  CosmicRenderer,
  CosmicAudioDirector,
  ChispaLavenderHost,
  CosmicEventController,
  PageMusicDirector,
  productionWebglAdapter,
  loadCanonicalEngine: loadCanonicalLavenderEngine,
  createView: createDomCosmicSceneView,
});

export async function createProductionCosmicController({
  doc = globalThis.document,
  win = globalThis.window,
  storage = globalThis.localStorage,
  layer,
  siteRoot = new URL('../', import.meta.url).href,
  dependencies = {},
} = {}) {
  const deps = { ...DEFAULT_DEPENDENCIES, ...dependencies };
  const svg = doc?.querySelector?.('#constellation');
  const group = doc?.querySelector?.('#lyra-group');
  const sky = doc?.querySelector?.('#sky');
  if (!svg || !group || !sky) throw new Error('Cosmic finale requires the live Chispa constellation and sky');
  if (!layer?.querySelector) throw new Error('Cosmic finale requires its isolated presentation layer');

  const vfxHost = layer.querySelector('.cosmic-vfx-host');
  const lavenderStage = layer.querySelector('.cosmic-lavender-stage');
  if (!vfxHost || !lavenderStage) throw new Error('Cosmic presentation layer is incomplete');

  const quality = selectQualityProfile(detectBrowserQualityEnvironment(win));
  const Engine = await deps.loadCanonicalEngine(siteRoot);
  const fracture = new deps.ConstellationFracture({
    svg, group,
    motionScale: quality.reducedMotion ? 0.68 : (quality.name === 'LITE' ? 0.82 : 1),
  });
  const renderer = new deps.CosmicRenderer({
    container: vfxHost,
    quality,
    webglAdapter: deps.productionWebglAdapter,
  });
  const ambientElements = ['#bg-music', '#altair-music', '#altair-music-2', '#deneb-player']
    .map((selector) => doc?.querySelector?.(selector))
    .filter(Boolean);
  const audio = new deps.CosmicAudioDirector({
    stemUrl: new URL('assets/cosmic/cosmic-event.wav', siteRoot).href,
  });
  const music = new deps.PageMusicDirector({
    url: new URL('assets/music/dandara-legacy.mp3', siteRoot).href,
    doc,
    legacyElements: ambientElements,
  });
  const lavender = new deps.ChispaLavenderHost({
    container: lavenderStage,
    Engine,
    reducedMotion: quality.reducedMotion,
  });
  const view = deps.createView({ layer, world: sky, vfxHost, quality });

  return new deps.CosmicEventController({
    fracture,
    renderer,
    audio,
    music,
    lavender,
    view,
    storage,
  });
}
