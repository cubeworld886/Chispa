function defaultAudioContextFactory() {
  const Ctor = globalThis.AudioContext || globalThis.webkitAudioContext;
  return Ctor ? new Ctor() : null;
}

export class CosmicAudioDirector {
  constructor({
    audioContextFactory = defaultAudioContextFactory,
    stemUrl = null,
    fetcher = globalThis.fetch?.bind(globalThis),
    now = () => globalThis.performance?.now?.() ?? Date.now(),
    gain = 1,
    ambientElements = [],
  } = {}) {
    this.audioContextFactory = audioContextFactory;
    this.stemUrl = stemUrl;
    this.fetcher = fetcher;
    this.now = now;
    this.gainValue = gain;
    this.ambientElements = Array.from(ambientElements || []).filter(Boolean);
    this.context = null;
    this.buffer = null;
    this.source = null;
    this.gainNode = null;
    this.audioStartedAt = null;
    this.visualStartedAt = null;
    this.authoritative = false;
    this.preloaded = false;
  }

  async preload() {
    if (this.preloaded && this.buffer) return true;
    if (!this.stemUrl || !this.fetcher) return false;
    try {
      this.context ||= this.audioContextFactory?.();
      if (!this.context) return false;
      const response = await this.fetcher(this.stemUrl);
      if (!response?.ok) return false;
      const bytes = await response.arrayBuffer();
      this.buffer = await this.context.decodeAudioData(bytes);
      this.preloaded = true;
      return true;
    } catch {
      this.buffer = null;
      this.preloaded = false;
      return false;
    }
  }

  silenceAmbient() {
    for (const element of this.ambientElements) {
      if (!element || element.paused === true) continue;
      try { element.pause?.(); } catch {}
    }
  }

  async start() {
    this.visualStartedAt = this.now();
    this.silenceAmbient();
    this.authoritative = false;
    if (!this.buffer || !this.context) return false;
    try {
      await this.context.resume?.();
      const source = this.context.createBufferSource();
      const gain = this.context.createGain();
      gain.gain.value = this.gainValue;
      source.buffer = this.buffer;
      source.connect(gain);
      gain.connect(this.context.destination);
      source.start(0);
      this.source = source;
      this.gainNode = gain;
      this.audioStartedAt = this.context.currentTime;
      this.authoritative = true;
      return true;
    } catch {
      this.source = null;
      this.gainNode = null;
      this.audioStartedAt = null;
      this.authoritative = false;
      return false;
    }
  }

  isAuthoritative() { return this.authoritative; }

  currentTime() {
    if (this.authoritative && this.context && this.audioStartedAt != null) {
      return Math.max(0, this.context.currentTime - this.audioStartedAt);
    }
    if (this.visualStartedAt == null) this.visualStartedAt = this.now();
    return Math.max(0, (this.now() - this.visualStartedAt) / 1000);
  }

  fadeOutAndStop(seconds = 0.25) {
    if (!this.source || !this.context) {
      this.stop();
      return;
    }
    const duration = Math.max(0, Number.isFinite(seconds) ? seconds : 0.25);
    const now = this.context.currentTime;
    const end = now + duration;
    const gainParam = this.gainNode?.gain;
    try { gainParam?.cancelScheduledValues?.(now); } catch {}
    try { gainParam?.setValueAtTime?.(Number.isFinite(gainParam?.value) ? gainParam.value : this.gainValue, now); } catch {}
    try { gainParam?.linearRampToValueAtTime?.(0, end); } catch {}
    try { this.source.stop(end); } catch { try { this.source.stop(); } catch {} }
    this.authoritative = false;
    this.audioStartedAt = null;
  }

  stop() {
    if (this.source) {
      try { this.source.stop(); } catch {}
      try { this.source.disconnect?.(); } catch {}
    }
    try { this.gainNode?.disconnect?.(); } catch {}
    this.source = null;
    this.gainNode = null;
    this.authoritative = false;
    this.audioStartedAt = null;
  }

  async destroy() {
    this.stop();
    const context = this.context;
    this.context = null;
    this.buffer = null;
    this.preloaded = false;
    try { await context?.close?.(); } catch {}
  }
}
