import { completedProgressFor, IDLE_SECONDS, LAVENDER_REVEAL_SECONDS, MUSIC_CUE_SECONDS, phaseAt, samplePhaseWindows } from './timeline.js';

export const COSMIC_STATE_KEY = 'chispa_cosmic_event_v1';

function defaultScheduler() {
  return {
    requestAnimationFrame: (fn) => globalThis.requestAnimationFrame(fn),
    cancelAnimationFrame: (id) => globalThis.cancelAnimationFrame(id),
    now: () => globalThis.performance?.now?.() ?? Date.now(),
  };
}

function safePersist(storage) {
  try { storage?.setItem?.(COSMIC_STATE_KEY, JSON.stringify({ version: 1, completed: true })); } catch {}
}


const clamp01 = (value) => Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0));

function windowValue(windows, name) {
  return clamp01(windows?.[name] ?? 0);
}

export function deriveCinematicShake(windows = {}, elapsed = 0, quality = {}) {
  const crack = windowValue(windows, 'crackPropagation');
  const waveA = windowValue(windows, 'shardWaveA');
  const waveB = windowValue(windows, 'shardWaveB');
  const waveC = windowValue(windows, 'shardWaveC');
  const singularity = windowValue(windows, 'singularity');
  const bigBang = windowValue(windows, 'bigBang');
  const debris = windowValue(windows, 'debrisExpansion');
  const aftermath = windowValue(windows, 'aftermath');

  let baseAmplitude = 0;
  if (crack > 0) baseAmplitude = Math.max(baseAmplitude, 0.55 + crack * 0.95);
  if (waveA > 0) baseAmplitude = Math.max(baseAmplitude, 1.35 + waveA * 1.25);
  if (waveB > 0) baseAmplitude = Math.max(baseAmplitude, 2.30 + waveB * 1.65);
  if (waveC > 0) baseAmplitude = Math.max(baseAmplitude, 3.45 + waveC * 2.05);
  if (singularity > 0) baseAmplitude = Math.max(baseAmplitude, 2.2 + singularity * 2.4);
  if (bigBang > 0) baseAmplitude = Math.max(baseAmplitude, 14.0 * Math.pow(1 - bigBang, 2));
  if (debris > 0) baseAmplitude = Math.max(baseAmplitude, 3.8 * Math.pow(1 - debris, 1.45));
  if (aftermath > 0) baseAmplitude = 0;

  const scale = Number.isFinite(quality.shakeScale) ? Math.max(0, quality.shakeScale) : 1;
  let amplitude = baseAmplitude * scale;
  if (quality.reducedMotion) amplitude = Math.min(amplitude, 0.9);

  const t = Number.isFinite(elapsed) ? elapsed : 0;
  const x = Math.sin(t * 83.0 + Math.sin(t * 13.1) * 0.75) * amplitude;
  const y = Math.cos(t * 71.0 + Math.sin(t * 11.7) * 0.55) * amplitude * 0.72;
  return Object.freeze({ amplitude, x, y });
}

export function deriveCinematicViewState({ windows = {}, elapsed = 0, quality = {} } = {}) {
  const shake = deriveCinematicShake(windows, elapsed, quality);
  const tension = windowValue(windows, 'tension');
  const crack = windowValue(windows, 'crackPropagation');
  const waveA = windowValue(windows, 'shardWaveA');
  const waveB = windowValue(windows, 'shardWaveB');
  const waveC = windowValue(windows, 'shardWaveC');
  const singularity = windowValue(windows, 'singularity');
  const primaryFlash = windowValue(windows, 'primaryFlash');
  const lavenderFlash = windowValue(windows, 'lavenderFlash');
  const debris = windowValue(windows, 'debrisExpansion');
  const aftermath = windowValue(windows, 'aftermath');
  const realization = windowValue(windows, 'realization');

  let exposure = 1;
  if (tension > 0) exposure = Math.max(exposure, 1 + tension * 0.075);
  if (crack > 0) exposure = Math.max(exposure, 1.045 + crack * 0.085);
  if (waveA > 0) exposure = Math.max(exposure, 1.08 + waveA * 0.055);
  if (waveB > 0) exposure = Math.max(exposure, 1.10 + waveB * 0.065);
  if (waveC > 0) exposure = Math.max(exposure, 1.12 + waveC * 0.075);
  if (singularity > 0) exposure = Math.max(exposure, 1.12 + singularity * 0.16);
  if (aftermath > 0 || realization > 0) exposure = 1;

  const flashScale = Number.isFinite(quality.flashScale) ? Math.max(0, quality.flashScale) : 1;
  const primaryPulse = primaryFlash > 0 ? Math.sin(primaryFlash * Math.PI) : 0;
  const lavenderPulse = lavenderFlash > 0 ? Math.sin(lavenderFlash * Math.PI) : 0;
  const flashOpacity = clamp01(Math.max(primaryPulse, lavenderPulse) * flashScale);
  const flashKind = lavenderPulse > primaryPulse ? 'lavender' : 'white';

  let veilOpacity = 0;
  if (debris > 0) veilOpacity = Math.max(veilOpacity, 0.12 + debris * 0.18);
  if (aftermath > 0) veilOpacity = Math.max(veilOpacity, 0.30 - aftermath * 0.06);
  if (realization > 0) veilOpacity = Math.max(veilOpacity, 0.22);

  return Object.freeze({
    shakeAmplitudePx: shake.amplitude,
    x: shake.x,
    y: shake.y,
    exposure,
    flashOpacity,
    flashKind,
    veilOpacity: clamp01(veilOpacity),
  });
}

export class CosmicEventController {
  constructor({ fracture, renderer, audio, music = null, lavender, view, scheduler = defaultScheduler(), storage = globalThis.localStorage }) {
    this.fracture = fracture;
    this.renderer = renderer;
    this.audio = audio;
    this.music = music;
    this.lavender = lavender;
    this.view = view;
    this.scheduler = scheduler;
    this.storage = storage;
    this.state = 'cold';
    this.origin = null;
    this.residualTargets = [];
    this.rafId = null;
    this.revealed = false;
    this.concerned = false;
    this.idleStarted = false;
    this.disposed = false;
    this.visualStartedAtMs = null;
    this.musicCued = false;
  }

  async preload() {
    if (this.state !== 'cold') return this;
    this.music?.silenceLegacy?.();
    await Promise.allSettled([
      Promise.resolve().then(() => this.renderer?.prewarm?.()),
      Promise.resolve().then(() => this.audio?.preload?.()),
      Promise.resolve().then(() => this.music?.preload?.()),
      Promise.resolve().then(() => this.lavender?.mount?.()),
    ]);
    this.lavender?.primeReveal?.();
    this.state = 'preloaded';
    return this;
  }

  arm() {
    if (this.state === 'cold') throw new Error('Cosmic event must preload before arm');
    if (this.state === 'preloaded') this.state = 'armed';
    return this;
  }

  async start({ auto = true } = {}) {
    if (this.state === 'cold') await this.preload();
    if (this.state === 'preloaded') this.arm();
    if (this.state !== 'armed') return false;

    this.fracture?.prepare?.();
    this.origin = this.fracture?.getOriginScreenPoint?.() ?? { x: 0, y: 0 };
    this.residualTargets = this.fracture?.getResidualTargets?.() ?? [];
    this.renderer?.setOrigin?.(this.origin);
    this.view?.setOrigin?.(this.origin);
    await Promise.resolve(this.audio?.start?.()).catch(() => false);
    this.visualStartedAtMs = this.scheduler.now?.() ?? globalThis.performance?.now?.() ?? Date.now();
    this.state = 'running';
    if (auto) this.#queueFrame();
    return true;
  }

  #queueFrame() {
    if (this.state !== 'running') return;
    this.rafId = this.scheduler.requestAnimationFrame((timestamp) => {
      this.rafId = null;
      if (this.state !== 'running') return;
      const now = Number.isFinite(timestamp) ? timestamp : (this.scheduler.now?.() ?? Date.now());
      const origin = Number.isFinite(this.visualStartedAtMs) ? this.visualStartedAtMs : now;
      const seconds = Math.max(0, (now - origin) / 1000);
      this.sample(seconds);
      if (this.state === 'running') this.#queueFrame();
    });
  }

  sample(seconds) {
    if (this.state !== 'running') return;
    const frame = phaseAt(seconds);
    const windows = samplePhaseWindows(seconds);
    const payload = { phase: frame.name, progress: frame.progress, elapsed: frame.seconds, windows };

    // View first: during the Lavender handoff the flash must already cover the renderer swap.
    this.view?.renderFrame?.(payload);

    // Glass transforms are durable state. Every stage is reconstructed from the
    // absolute playhead so dropped frames cannot skip a crack, shard wave or impulse.
    const tensionProgress = completedProgressFor('tension', seconds);
    const crackSeedProgress = completedProgressFor('crackSeed', seconds);
    const crackPropagationProgress = completedProgressFor('crackPropagation', seconds);
    const waveA = completedProgressFor('shardWaveA', seconds);
    const waveB = completedProgressFor('shardWaveB', seconds);
    const waveC = completedProgressFor('shardWaveC', seconds);
    const explosionProgress = completedProgressFor('bigBang', seconds);
    if (tensionProgress > 0) this.fracture?.tension?.(tensionProgress);
    if (crackSeedProgress > 0) this.fracture?.crackSeed?.(crackSeedProgress);
    if (crackPropagationProgress > 0) this.fracture?.crackPropagation?.(crackPropagationProgress);
    if (waveA > 0) this.fracture?.releaseWave?.('A', waveA);
    if (waveB > 0) this.fracture?.releaseWave?.('B', waveB);
    if (waveC > 0) this.fracture?.releaseWave?.('C', waveC);
    if (explosionProgress > 0) this.fracture?.applyExplosion?.(explosionProgress, seconds);

    this.renderer?.sample?.(payload);

    if (!this.musicCued && seconds >= MUSIC_CUE_SECONDS) {
      this.musicCued = true;
      if (typeof this.audio?.fadeOutAndStop === 'function') this.audio.fadeOutAndStop(0.25);
      else this.audio?.stop?.();
      void Promise.resolve(this.music?.startFromBeginning?.()).catch(() => false);
    }

    if (!this.revealed && seconds >= LAVENDER_REVEAL_SECONDS) {
      this.revealed = true;
      if (typeof this.lavender?.revealCentered === 'function') this.lavender.revealCentered();
      else this.lavender?.revealFromStar?.(this.origin);
    }

    if (!this.concerned && seconds >= 11.35) {
      this.concerned = true;
      this.lavender?.enterConcerned?.();
    }

    if (seconds >= 11.35 && seconds < IDLE_SECONDS) this.#driveRealization(seconds);
    if (!this.idleStarted && seconds >= IDLE_SECONDS) this.#enterIdle();
  }

  #driveRealization(seconds) {
    const age = seconds - 11.35;
    const targets = this.fracture?.getResidualTargets?.() ?? this.residualTargets;
    if (age < 1.15) {
      const first = targets[0];
      if (first) this.lavender?.lookAtWorldPoint?.(first.x, first.y);
    } else if (age < 2.15) {
      const second = targets[1] ?? targets[0];
      if (second) this.lavender?.lookAtWorldPoint?.(second.x, second.y);
    } else {
      this.lavender?.lookDown?.();
    }
  }

  #enterIdle() {
    this.idleStarted = true;
    this.renderer?.disposeHeavyVfx?.();
    this.fracture?.releaseHeavyPreparation?.();
    this.fracture?.enterResidualDrift?.(IDLE_SECONDS);
    this.view?.settleFinal?.();
    this.lavender?.startMelancholicIdle?.(() => this.fracture?.getResidualTargets?.() ?? []);
    safePersist(this.storage);
    if (this.rafId != null) this.scheduler.cancelAnimationFrame(this.rafId);
    this.rafId = null;
    this.music?.keepPlayingThroughIdle?.();
    this.state = 'idle';
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    if (this.rafId != null) this.scheduler.cancelAnimationFrame(this.rafId);
    this.rafId = null;
    this.renderer?.disposeHeavyVfx?.();
    this.fracture?.destroy?.({ restoreOriginal: true });
    this.audio?.stop?.();
    this.music?.destroy?.();
    this.lavender?.destroy?.();
    this.view?.destroy?.();
    this.state = 'disposed';
  }
}

export function createDomCosmicSceneView({ layer, world, vfxHost, quality = {} }) {
  const flash = layer.querySelector('.cosmic-flash');
  const veil = layer.querySelector('.cosmic-void-veil');
  let origin = { x: 0, y: 0 };
  const flashScale = Number.isFinite(quality.flashScale) ? quality.flashScale : 1;
  const shakeScale = Number.isFinite(quality.shakeScale) ? quality.shakeScale : 1;

  const setOrigin = (point) => {
    origin = { ...point };
    layer.style.setProperty('--cosmic-origin-x', `${point.x}px`);
    layer.style.setProperty('--cosmic-origin-y', `${point.y}px`);
  };

  const renderFrame = ({ phase, progress, elapsed, windows }) => {
    layer.dataset.phase = phase;
    layer.style.setProperty('--cosmic-time', String(elapsed));
    const state = deriveCinematicViewState({ windows, elapsed, quality: { ...quality, flashScale, shakeScale } });

    if (flash) {
      flash.style.opacity = String(state.flashOpacity);
      flash.dataset.kind = state.flashKind;
    }
    if (veil) veil.style.opacity = String(state.veilOpacity);

    const transform = state.shakeAmplitudePx > 0.025
      ? `translate3d(${state.x}px,${state.y}px,0)`
      : '';
    if (world) {
      world.style.transform = transform;
      world.style.filter = state.exposure > 1.001
        ? `brightness(${state.exposure}) saturate(${1 + (state.exposure - 1) * 0.8})`
        : '';
    }
    if (vfxHost) vfxHost.style.transform = transform;
  };

  return {
    setOrigin,
    renderFrame,
    settleFinal() {
      layer.dataset.phase = 'melancholicIdle';
      flash && (flash.style.opacity = '0');
      if (world) { world.style.transform = ''; world.style.filter = ''; }
      if (vfxHost) vfxHost.style.transform = '';
      if (veil) veil.style.opacity = '.22';
    },
    destroy() {
      if (world) { world.style.transform = ''; world.style.filter = ''; }
      layer.remove?.();
    },
    getOrigin: () => ({ ...origin }),
  };
}
