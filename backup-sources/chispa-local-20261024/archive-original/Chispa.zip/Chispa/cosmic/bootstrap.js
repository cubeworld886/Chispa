import { AUTOSTART_DELAY_MS } from './timeline.js';
export { AUTOSTART_DELAY_MS } from './timeline.js';

export function isDebugReplay(search = globalThis.location?.search ?? '') {
  try {
    return new URLSearchParams(search).get('cosmicReplay') === '1';
  } catch {
    return false;
  }
}

function defaultTimeoutScheduler() {
  return {
    setTimeout: (fn, ms) => globalThis.setTimeout(fn, ms),
    clearTimeout: (id) => globalThis.clearTimeout(id),
  };
}

export function installCosmicBootstrap({
  createController,
  scheduler = defaultTimeoutScheduler(),
  delayMs = AUTOSTART_DELAY_MS,
} = {}) {
  if (typeof createController !== 'function') throw new Error('Cosmic bootstrap requires createController');

  let controllerPromise = null;
  let preloadPromise = null;
  let started = false;
  let disposed = false;
  let timerId = null;

  const ensureController = () => {
    if (!controllerPromise) controllerPromise = Promise.resolve().then(() => createController());
    return controllerPromise;
  };

  const ensurePreloaded = () => {
    if (disposed) return Promise.resolve(null);
    if (!preloadPromise) {
      preloadPromise = ensureController().then(async (controller) => {
        await controller?.preload?.();
        return controller;
      });
    }
    return preloadPromise;
  };

  const startOnce = async () => {
    if (started || disposed) return false;
    started = true;
    try {
      const controller = await ensurePreloaded();
      if (!controller || disposed) return false;
      controller.arm?.();
      await controller.start?.();
      return true;
    } catch {
      started = false;
      return false;
    }
  };

  void ensurePreloaded();
  timerId = scheduler.setTimeout(() => {
    timerId = null;
    void startOnce();
  }, Math.max(0, Number(delayMs) || 0));

  return {
    preload: ensurePreloaded,
    start: startOnce,
    dispose() {
      if (disposed) return;
      disposed = true;
      if (timerId != null) scheduler.clearTimeout(timerId);
      timerId = null;
      void controllerPromise?.then((controller) => controller?.dispose?.()).catch(() => {});
    },
  };
}

export function resolveCosmicSiteRoot(moduleUrl = import.meta.url) {
  return new URL('../', moduleUrl).href;
}

export function createCosmicLayer(doc = globalThis.document) {
  const existing = doc?.querySelector?.('#cosmic-event-layer');
  if (existing) return existing;
  if (!doc?.createElement || !doc?.body?.append) throw new Error('Cosmic layer requires a document body');
  const layer = doc.createElement('div');
  layer.id = 'cosmic-event-layer';
  layer.className = 'cosmic-event-layer';
  layer.setAttribute('aria-hidden', 'true');
  layer.innerHTML = `
    <div class="cosmic-void-veil"></div>
    <div class="cosmic-vfx-host"></div>
    <div class="cosmic-lavender-stage"></div>
    <div class="cosmic-flash" data-kind="white"></div>
  `;
  doc.body.append(layer);
  return layer;
}

export function installProductionCosmicBootstrap({
  doc = globalThis.document,
  win = globalThis.window,
  scheduler = defaultTimeoutScheduler(),
  delayMs = AUTOSTART_DELAY_MS,
  runtimeLoader = () => import('./production-runtime.js'),
  moduleUrl = import.meta.url,
} = {}) {
  const siteRoot = resolveCosmicSiteRoot(moduleUrl);
  return installCosmicBootstrap({
    scheduler,
    delayMs,
    createController: async () => {
      const layer = createCosmicLayer(doc);
      const runtime = await runtimeLoader();
      return runtime.createProductionCosmicController({ doc, win, layer, siteRoot });
    },
  });
}

if (typeof document !== 'undefined') {
  installProductionCosmicBootstrap();
}
